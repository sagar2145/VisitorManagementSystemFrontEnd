sap.ui.define([
	"com/incture/cherrywork/GuestManagmentSystem/test/unit/controller/HomePage.controller"
], function () {
	"use strict";
});